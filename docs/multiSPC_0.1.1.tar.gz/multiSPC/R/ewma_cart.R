#' Une fonction qui renvoie les valeurs d'une carte EWMA pour une matrice X(k,n)
#' k étant le nombre de prélèvement et n le nombre d'observations.

#'
#' @param data La matrice X de dimensions k,p,n
#' @param lambda Paramètre d'autocorrélation
#' @param L Coefficient pour LIC,LSC
#' @return La covariance empirique
#' @export


ewma_cart=function(data,lambda=0.4,L=3){
  mu=mean(data)
  sI=sigma_I(data)
  M=apply(data,1,mean)
  k=dim(data)[1]
  n=dim(data)[2]
  z=rep(NA,k)
  LIC=rep(NA,k)
  LSC=rep(NA,k)
  z[1]=mu
  for(i in 2:k){
    z[i]=lambda*M[i]+(1-lambda)*z[i-1]
  }

  for(i in 1:k){
    LIC[i]=mu-L*sI*sqrt(lambda*(1-(1-lambda)^(2*i))/(2-lambda))/sqrt(n)
    LSC[i]=mu+L*sI*sqrt(lambda*(1-(1-lambda)^(2*i))/(2-lambda))/sqrt(n)
  }

  df=data.frame(t=1:k,z=z,LIC=LIC,LSC=LSC)
  return(df)
}
