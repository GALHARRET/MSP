#' T2 Hotelling Parafac
#'
#' @param A mode A
#' @param S matrice de covariance du mode A
#'
#' @returns
#' @export
#'
#' @examples
T2_Hotelling_Parafac<-function(A,S=cov(A)){
  T2 <- apply(A, 1, function(t) t(t) %*% solve(S) %*% t)
return(T2)
}
