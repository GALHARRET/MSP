#' Predict avec parafac
#'
#' @param X_new newdata
#' @param model model from the training dataset
#'
#' @returns list
#' @export
#'
#' @examples
predict_parafac <- function(X_new, model) {
  if (length(dim(X_new)) != 3) stop("X_new is a tensor")

  A <- model$A
  B <- model$B
  C <- model$C

  I_new <- dim(X_new)[1]
  J <- dim(X_new)[2]
  K <- dim(X_new)[3]
  F <- ncol(B)

  khatri_rao <- function(M1, M2) {
    do.call(cbind, lapply(1:ncol(M1), function(f) kronecker(M1[,f], M2[,f])))
  }


  X1 <- matrix(aperm(X_new, c(1,2,3)), nrow = I_new)

  KR <- khatri_rao(C, B)
  A_new <- X1 %*% KR %*% solve(t(KR) %*% KR)

  X_hat <- multiway::fitted.parafac(list(A = A_new, B = B, C = C))


  SPE <- sapply(1:I_new, function(i) sum((X_new[i,,] - X_hat[i,,])^2))


  var_total <- apply(X_new, 1, function(x) sum((x - mean(x))^2))
  R2 <- 1 - SPE / var_total

  return(list(A_new = A_new, X_hat = X_hat, SPE = SPE, R2 = R2))
}
